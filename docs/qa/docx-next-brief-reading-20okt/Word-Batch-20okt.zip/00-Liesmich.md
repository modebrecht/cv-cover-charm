# Word-Batch: gemeinsamer CV-Lesefluss - 20. Oktober

Die Nummern bleiben zu den bisherigen Rueckgaben kompatibel. Acht echte App-DOCX,
fuenf Brief-Varianten und drei unveraenderte Modern-Kontrollen.

## Eine spaetere gemeinsame Pruefrunde

1. 11: CV auf genau einer Seite inklusive Referenz; Datum/Eintrag und Sprache/Niveau
   nebeneinander, native Aufzaehlungen und Kontaktabstaende ansehen.
2. 12: CV auf zwei Seiten; gleicher Abstand zum Seitenanfang, logische Fortsetzung.
3. 09: Kontaktblock und neue Zeilen ansehen. Ohne Preset bleiben in der zusaetzlichen
   LibreOffice-Vorschau zwei CV-Seiten gegenueber einer im normalen App-PDF offen.
4. Nur 11 kurz bearbeiten (eine Sprache und einen Listenpunkt), speichern, schliessen,
   wieder oeffnen. Danach einmal gesammelt Rueckmeldung geben.

08/10 sind Standard-/Fotovarianten desselben CV-Pfads. 01/04/05 sind bytegleiche
Kontrollen des Headerstandard-Pakets. Keine neue Komplettabnahme dieser Kontrollen;
die bereits offene Headerpruefung von 04 bleibt bestehen.

## Was verbessert ist

Brief verwendet im QA-App-Export dieselbe vorhandene klassische CV-Zeilenlogik wie
der Modern-Test: Datumsleiste, Sprachenspalten, echte Listen, schmale Spalten und
Seitenpresets. Keine neuen Web-Defaults, Schriften, Headerabstaende oder Benutzerwerte.

## Grenzen

PDF-Referenzen stammen aus dem normalen App-Download desselben gespeicherten Projekts.
Sie sind keine Word-PDFs. Die Vorschau in der Uebersicht stammt aus LibreOffice und
ersetzt keine Microsoft-Word-Abnahme. 08/09/10 sowie Kontrolle 05 behalten ohne
Einseitenaktion die bekannte zusaetzliche native CV-Seite. Allgemeine Schriftrollen,
Rubrikdarstellung und Brief-Chrome stimmen noch nicht vollstaendig mit Web/PDF ueberein.
Die Zahlen in der Uebersicht benennen diese Abweichungen ausdruecklich.

Andere Fonts und Coverfamilien (Verlauf, Neon, Warm/Freundlich) bleiben gesperrt.
Native Sidebar und Agent A bleiben eingefroren. Verschobene persoenliche Angaben,
freie CV-Elemente und andere native CV-Aufbauten werden im Lesefluss-Test abgewiesen.
Kein Merge, Deployment oder Wechsel des produktiven Standardexports.

## Automatisierter Nachweis

1'254 Unit-Tests (0 Fehler), Typecheck, Lint (0 Fehler / 21 bestehende Warnungen),
Format und Build bestanden. Acht Restores mit Reload und echten UI-Downloads;
31 native Vorschauseiten, 649 native Feldinhalte, alle Absatztexte und Originalbilder
geprueft. Alle 31 Seiten visuell ueber 22 unterschiedliche Seitenrastern kontrolliert.
11/12 ergeben genau eine/zwei native CV-Seiten. Bei 08/09/10 sind Web-Bilder,
gespeicherte Eingaben, Deckblatt-/Anschreibenmodelle und alle CV-Feldidentitaeten und
Texte gegen den unberuehrten Remote-Checkpoint identisch. Nur der CV-Lesefluss aendert sich.

Arbeitsbranch: fix/docx-next-shared-fidelity-18okt
Basis: 3f845b75082a47aa57672d5c814fceae238364ce
Microsoft Word: neue Dateien UNVERIFIED.
